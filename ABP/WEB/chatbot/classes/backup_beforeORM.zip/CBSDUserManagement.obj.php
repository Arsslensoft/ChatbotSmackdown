<?php

	class CBSDUserManagement
	{

		private $mysqli, $stmt;
		private $sessionName = "CBSDUserManagement";
		public $logged_in = false;


		/**
		* Object construct verifies that a session has been started and that a MySQL connection can be established.
		* It takes no parameters.
		*
		* @exception	Exception	If a session id can't be returned.
		*/

		public function __construct()
		{
			$sessionId = session_id();
			if( strlen($sessionId) == 0)
				throw new Exception("No session has been started.\n<br />Please add `session_start();` initially in your file before any output.");

			$this->mysqli = new mysqli($GLOBALS["mysql_hostname"], $GLOBALS["mysql_username"], $GLOBALS["mysql_password"], $GLOBALS["mysql_database"]);
			if( $this->mysqli->connect_error )
				throw new Exception("MySQL connection could not be established: ".$this->mysqli->connect_error);

			$this->_validateUser();
			$this->_updateActivity();
		}
		// User Management
		
		public function createUser($username, $email, $firstname, $lastname,$botname,$password )
		{
			$salt = $this->_generateSalt();
			$password = $salt.$password;

			$sql = "INSERT INTO users(Username, Email, FirstName, LastName,BotName, Password, Salt) VALUES (?,?,?,?,?,SHA1(?), ?))";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("sssssss", $username, $email, $firstname, $lastname,$botname,$password, $salt);
			if( $this->stmt->execute() )
				return $this->stmt->insert_id;
				
			return false;
		}
		public function loginUser( $username, $password )
		{
			$sql = "SELECT Id FROM users WHERE Username=? AND SHA1(CONCAT(uSalt, ?))=Password LIMIT 1";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("ss", $username, $password);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return false;

			$this->stmt->bind_result($userId);
			$this->stmt->fetch();

			$_SESSION[$this->sessionName]["Id"] = $userId;
			$_SESSION[$this->sessionName]["user"] = $username;
			$this->logged_in = true;

			return $userId;
		}
		public function logoutUser()
		{
			if( isset($_SESSION[$this->sessionName]) )
				unset($_SESSION[$this->sessionName]);

			$this->logged_in = false;
		}
    	public function setPassword( $password, $userId = null )
		{

			if( $userId == null )
				$userId = $_SESSION[$this->sessionName]["Id"];

			$salt = $this->_generateSalt();
			$password = $salt.$password;

			$sql = "UPDATE users SET Password=SHA1(?), Salt=? WHERE Id=? LIMIT 1";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("ssi", $password, $salt, $userId);
			return $this->stmt->execute();
		}
		public function getUsers()
		{
			
			$sql = "SELECT DISTINCT  Id,Username,FirstName,LastName,Role,Activity,BotName,BotDescription,BotScore,BotActive FROM users ORDER BY Username ASC";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id,$Username,	$FirstName,	$LastName,	$Role,$Activity,$BotName,$BotDescription,$BotScore,$BotActive);
			$users = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$users[$i]["Id"] = $Id;
				$users[$i]["Username"] = $Username;
				$users[$i]["FirstName"] = $FirstName;
				$users[$i]["LastName"] = $LastName;
				$users[$i]["Role"] = $Role;
				$users[$i]["Activity"] = $Activity;
				$users[$i]["BotName"] = $BotName;
				$users[$i]["BotDescription"] = $BotDescription;
				$users[$i]["BotScore"] = $BotScore;
				$users[$i]["BotActive"] = $BotActive;
				$i++;
			}

			return $users;

		}
		public function getSingleUser( $userId = null )
		{

			if( $userId == null )
				$userId = $_SESSION[$this->sessionName]["userId"];

			$sql = "SELECT Id,Username,FirstName,LastName,Role,Activity,BotName,BotDescription,BotScore,BotActive  FROM users WHERE Id=? LIMIT 1";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $userId);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return false;

			$this->stmt->bind_result($Id,$Username,	$FirstName,	$LastName,	$Role,$Activity,$BotName,$BotDescription,$BotScore,$BotActive);
			$this->stmt->fetch();

			$users["Id"] = $Id;
			$users["Username"] = $Username;
			$users["FirstName"] = $FirstName;
			$users["LastName"] = $LastName;
			$users["Role"] = $Role;
			$users["Activity"] = $Activity;
			$users["BotName"] = $BotName;
			$users["BotDescription"] = $BotDescription;
			$users["BotScore"] = $BotScore;
			$users["BotActive"] = $BotActive;

			return $users;

		}
		public function updateUser($id,$username, $email, $firstname, $lastname,$botname,$botdesc,$botactive,$password)
		{
			$salt = $this->_generateSalt();
			$password = $salt.$password;

			$sql = "UPDATE `users` SET Username=?,Password=?,Email=?,FirstName=?,LastName=?,BotName=?,BotDescription=?,BotActive=?,Salt=?WHERE Id=?";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("sssssssisi", $username, $password,$email, $firstname, $lastname,$botname,$botdesc,$botactive, $salt, $id);
			if( $this->stmt->execute() )
				true;
			return false;
		}
		public function getToken( $xhtml = true )
		{
			$token = $this->_generateSalt();
			$name = "token_".md5($token);
			
			$_SESSION[$this->sessionName]["csrf_name"] = $name;
			$_SESSION[$this->sessionName]["csrf_token"] = $token;
			
			$string = "<input type=\"hidden\" name=\"".$name."\" value=\"".$token."\"";
			if($xhtml)
				$string .= " />";
			else
				$string .= ">";
			
			return $string;
		}		
		public function validateToken()
		{
			$name = $_SESSION[$this->sessionName]["csrf_name"];
			$token = $_SESSION[$this->sessionName]["csrf_token"];
			unset($_SESSION[$this->sessionName]["csrf_token"]);
			unset($_SESSION[$this->sessionName]["csrf_name"]);
			
			if($_POST[$name] == $token)
				return true;
				
			return false;
		}

		// Bot Settings Management
		public function addAimlSet($bid, $aimlfile)
		{
			$sql = "INSERT INTO aimlsets(BotId, AimlFile) VALUES (?, ?)";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("is", $bid,$aimlfile);
			if( $this->stmt->execute() )
				return $this->stmt->insert_id;

			return false;
		}
		public function addPersonality($bid, $personalityfile)
		{
			$sql = "INSERT INTO personalities(BotId, PersonalityFile) VALUES (?, ?)";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("is", $bid,$personalityfile);
			if( $this->stmt->execute() )
				return $this->stmt->insert_id;

			return false;
		}
		public function removeAimlSet($id)
		{
			$sql = "DELETE FROM aimlsets WHERE Id=?";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $id);
			if( $this->stmt->execute() )
				return true;

			return false;
		}
		public function removePersoality($id)
		{
			$sql = "DELETE FROM personalities WHERE Id=?";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $id);
			if( $this->stmt->execute() )
				return true;

			return false;
		}
		public function getAllAimlSets($uid)
		{
			$sql = "SELECT Id,BotId,AimlFile FROM aimlsets WHERE BotId = ?";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $uid);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id,$BotId, $AimlFile);
			$aimls = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$aimls[$i]["Id"] = $Id;
				$aimls[$i]["BotId"] = $BotId;
				$aimls[$i]["AimlFile"] = $AimlFile;

				$i++;
			}

			return $aimls;
		}
		public function getAllPersonalities($uid)
		{
			$sql = "SELECT Id,BotId,PersonalityFile FROM personalities WHERE BotId = ?";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $uid);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id,$BotId, $PersonalityFile);
			$aimls = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$aimls[$i]["Id"] = $Id;
				$aimls[$i]["BotId"] = $BotId;
				$aimls[$i]["PersonalityFile"] = $PersonalityFile;

				$i++;
			}

			return $aimls;
		}



		private function _updateActivity()
		{
			if( !$this->logged_in )
				return;

			$userId = $_SESSION[$this->sessionName]["Id"];

			$sql = "UPDATE users SET Activity=NOW() WHERE Id=? LIMIT 1";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $userId);
			$this->stmt->execute();
			return;
		}
		private function _validateUser()
		{
			if( !isset($_SESSION[$this->sessionName]["Id"]) )
				return;

			if( !$this->_validateUserId() )
				return;

			$this->logged_in = true;
		}
		private function _validateUserId()
		{
			$userId = $_SESSION[$this->sessionName]["Id"];

			$sql = "SELECT userId FROM users WHERE Id=? LIMIT 1";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $userId);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 1)
				return true;

			$this->logoutUser();

			return false;
		}
		private function _generateSalt()
		{
			$salt = null;

			while( strlen($salt) < 128 )
				$salt = $salt.uniqid(null, true);

			return substr($salt, 0, 128);
		}

	}
	
?>