<?php
require_once(dirname(__FILE__)."/JsonSerializer/JsonSerializer.php");
require_once(dirname(__FILE__)."/Enum.obj.php");
require_once(dirname(__FILE__)."/SimpleOrm.class.php");

/*
class UserRole extends Enum
{
    const __default = self::User;
    const User = 0;
    const Administrator = 1;
}
class CompetitionStatus extends Enum
    {
     const __default = self::Ready;
      const  Ready = 0;
        const Started = 1;
        const Completed = 2;
    }
class GameStatus extends Enum
{
const Pending=0;
const Playing=1;
const Voting=2;
const Completed=3;
}
*/

class DataMappingManager
{
    public static function initializeMapper($conn = null)
    {
    if($conn == null) {
        // Connect to the database using mysqli
        $conn = new mysqli($GLOBALS["mysql_hostname"], $GLOBALS["mysql_username"], $GLOBALS["mysql_password"], $GLOBALS["mysql_database"]);
        if( $conn->connect_error )
            throw new Exception("MySQL connection could not be established: ".$this->mysqli->connect_error);
    }

SimpleOrm::useConnection($conn, $GLOBALS["mysql_database"]);
        
    }
}

abstract class SerializableModel extends SimpleOrm {
    public function serialize() {
        $serializer = new JsonSerializer();
        return $serializer->serialize($this);
    }


    public static function deserialize($json, $typename = null) {
        $serializer = new JsonSerializer();
        if($typename != null)
              return  $serializer->unserializeWithTypeName($json, $typename);
        else
            return $serializer->unserialize($json);

    }

}

// Database classes
class DatabaseObject extends SerializableModel{
    protected $Id;
    public function getId()
    {
        return $this->Id;
    }
    public function setId($Id)
    {
        $this->Id = $Id;
    }

}
class AimlSet extends DatabaseObject
{
    private $BotId;
    private $AimlFile;

}
class Competition extends DatabaseObject
{
private $Start ;
private $Name;
private $Description;
private $Status ;
      // Prize
private $PointsPerWin ;
private $Prize ;
private $ParticipantNumber ;
}
class Game extends  DatabaseObject
{
    private $RoundId;
    private $Status;
    private $Start ;
    private $Duration;
    private $PlayerSleepTime ;
    private $WinnerId;
    private $ChatHistoryFile;
}
class Participation extends DatabaseObject
    {
         private $BotId;
        private $CompetitionId;
            private $JoinDate;
    }
class Personality extends DatabaseObject
    {
    private $BotId ;
    private $PersonalityFile;
    }
class Ranking extends  DatabaseObject
{
private $BotId;
private $CompetitionId;
private $Rank;
}
class Round extends DatabaseObject
{
private $CompetitionId;
private $Number;
}
class Player extends DatabaseObject
{
    private $GameId ;
private $BotId ;
private $Score ;
    private $Votes;
}
class Visitor extends DatabaseObject
{
    private $BotId;
    private $VisitorIdentifier;
}
class User extends DatabaseObject {
    private $Username;
    private $Password;
    private $Email;
    private $FirstName;
    private $LastName;
    private $Role;
    private $Salt;
    private $Activity;
    // Bot part
    private $BotName;
    private $BotDescription;
    private $BotScore;
    private $BotActive;
}






/*

$content = new User();
$content->setId(5);
$json= $content->serialize();
echo $json;
$u = User::deserialize($json,User::class);
echo $u->getId();*/

?>