<?php

	/**
	* Configuration file
	*
	* This should be the only file you need to edit in, regarding the original script.
	* Please provide your MySQL login information below.
	*/

	$GLOBALS["mysql_hostname"] = "localhost";
	$GLOBALS["mysql_username"] = "root";
	$GLOBALS["mysql_password"] = "";
	$GLOBALS["mysql_database"] = "cbsd";


?>