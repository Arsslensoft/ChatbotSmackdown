<?php

	$path = dirname(__FILE__);
	
	include($path."/config.inc.php");
	include($path."/ABPS.API.obj.php");
	include($path."/CBSDUserManagement.obj.php");
	
?>