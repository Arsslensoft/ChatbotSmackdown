<?php

	class CBSDCompetitionManagement
	{

		public function createCompetition($start,$name,$description,$ppw, $prize, $pn)
		{
			$sql = "INSERT INTO participations(Start, `Name`, Description, PointsPerWin, Prize, ParticipantNumber, Status) VALUES (?, ?, ?, ?, ?, ?, 0)";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("sssiii", $start,$name,$description,$ppw,$prize,$pn);
			if( $this->stmt->execute() )
				return $this->stmt->insert_id;

			return false;
		}
		public function joinCompetition($cid, $bid)
		{

			$sql = "INSERT INTO participations(BotId, CompetitionId, JoinDate) VALUES (?,?,NOW())";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("ii", $bid,$cid);
			if( $this->stmt->execute() )
				return $this->stmt->insert_id;

			return false;
		}
		public function getCompetition($id)
		{
			$sql = "SELECT Id, Start, `Name`, Description, PointsPerWin, Prize, ParticipantNumber, Status FROM competitions WHERE Id=?";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $id);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id, $Start, $Name, $Description, $PointsPerWin, $Prize, $ParticipantNumber, $Status);
			$compet = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$compet[$i]["Id"] = $Id;
				$compet[$i]["Start"] = $Start;
				$compet[$i]["Name"] = $Name;
				$compet[$i]["Description"] = $Description;
				$compet[$i]["PointsPerWin"] = $PointsPerWin;
				$compet[$i]["Prize"] = $Prize;
				$compet[$i]["ParticipantNumber"] = $ParticipantNumber;
				$compet[$i]["Status"] = $Status;

				$i++;
			}

			return $compet;
		}
		public function getAllCompetitions()
		{
			$sql = "SELECT Id, Start, `Name`, Description, PointsPerWin, Prize, ParticipantNumber, Status FROM competitions";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id, $Start, $Name, $Description, $PointsPerWin, $Prize, $ParticipantNumber, $Status);
			$compet = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$compet[$i]["Id"] = $Id;
				$compet[$i]["Start"] = $Start;
				$compet[$i]["Name"] = $Name;
				$compet[$i]["Description"] = $Description;
				$compet[$i]["PointsPerWin"] = $PointsPerWin;
				$compet[$i]["Prize"] = $Prize;
				$compet[$i]["ParticipantNumber"] = $ParticipantNumber;
				$compet[$i]["Status"] = $Status;

				$i++;
			}

			return $compet;
		}


		// Rounds Management
		public function getAllRounds($cid)
		{
			$sql = "SELECT Id, CompetitionId, `Number` FROM rounds WHERE CompetitionId=?";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $cid);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id, $CompetitionId, $Number);
			$rounds = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$rounds[$i]["Id"] = $Id;
				$rounds[$i]["CompetitionId"] = $CompetitionId;
				$rounds[$i]["Number"] = $Number;

				$i++;
			}

			return $rounds;
		}
		public function getAllGames($rid)
		{
			$sql = "SELECT `Id`, `RoundId`, `Status`, `Start`, `Duration`, `WinnerId`, `ChatHistoryFile`, `PlayerSleepTime` FROM `games` WHERE RoundId=?";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $rid);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id, $RoundId, $Status, $Start, $Duration, $WinnerId, $ChatHistoryFile, $PlayerSleepTime);
			$games = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$games[$i]["Id"] = $Id;
				$games[$i]["RoundId"] = $RoundId;
				$games[$i]["Status"] = $Status;
				$games[$i]["Start"] = $Start;
				$games[$i]["Duration"] = $Duration;
				$games[$i]["WinnerId"] = $WinnerId;
				$games[$i]["ChatHistoryFile"] = $ChatHistoryFile;
				$games[$i]["PlayerSleepTime"] = $PlayerSleepTime;

				$i++;
			}

			return $games;
		}
		public function getAllPlayers($gid)
		{
			$sql = "SELECT Id, GameId, BotId, Score,Votes FROM players WHERE GameId=?";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $gid);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id, $GameId, $BotId, $Score, $Votes);
			$players = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$players[$i]["Id"] = $Id;
				$players[$i]["GameId"] = $GameId;
				$players[$i]["BotId"] = $BotId;
				$players[$i]["Score"] = $Score;
				$players[$i]["Votes"] = $Votes;
				$i++;
			}

			return $players;
		}
		public function getAllRankings($cid)
		{
			$sql = "SELECT Id, CompetitionId, BotId, Rank FROM rankings WHERE CompetitionId=?";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $cid);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id, $CompetitionId, $BotId, $Rank);
			$players = array();

			$i = 0;
			while( $this->stmt->fetch() )
			{

				$players[$i]["Id"] = $Id;
				$players[$i]["CompetitionId"] = $CompetitionId;
				$players[$i]["BotId"] = $BotId;
				$players[$i]["Rank"] = $Rank;
				$i++;
			}

			return $players;
		}

		// Game Management
		public function voteForPlayer($gid, $bid)
		{
			$sql = "UPDATE `players` SET `Votes`=`Votes` + 1 WHERE GameId=? AND BotId = ?";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("ii",$gid,$bid);
			if( $this->stmt->execute() )
				true;
			return false;
		}
		public function getGame($gid)
		{
			$sql = "SELECT `Id`, `RoundId`, `Status`, `Start`, `Duration`, `WinnerId`, `ChatHistoryFile`, `PlayerSleepTime` FROM `games` WHERE Id=?";

			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$this->stmt->bind_param("i", $gid);
			$this->stmt->execute();
			$this->stmt->store_result();

			if( $this->stmt->num_rows == 0)
				return array();

			$this->stmt->bind_result($Id, $RoundId, $Status, $Start, $Duration, $WinnerId, $ChatHistoryFile, $PlayerSleepTime);
				 $this->stmt->fetch();

				$games["Id"] = $Id;
				$games["RoundId"] = $RoundId;
				$games["Status"] = $Status;
				$games["Start"] = $Start;
				$games["Duration"] = $Duration;
				$games["WinnerId"] = $WinnerId;
				$games["ChatHistoryFile"] = $ChatHistoryFile;
				$games["PlayerSleepTime"] = $PlayerSleepTime;



			return $games;
		}

	}

	
?>